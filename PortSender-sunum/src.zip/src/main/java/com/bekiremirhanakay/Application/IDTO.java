package com.bekiremirhanakay.Application;public interface IDTO {
    public String getDataType();
}
